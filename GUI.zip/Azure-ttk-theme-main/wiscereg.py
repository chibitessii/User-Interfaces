import sounddevice as sd
import json, time, ast, os, csv, sys, subprocess
import urllib.request as urlreq
import urllib.parse as urlparse

HOSTNAME = 'ASIO'
DEVNAME = 'Cirrus Logic ASIO Driver'
#HOSTNAME = 'WASAPI'
#DEVNAME = 'Lochnagar'
MIN_CHANNELS = 16
RATE = 48000
DURATION = 10

def get_reg_value(val, dictlist): 
# This function allows the device dictionary to be read and chosen from 
	for key, number in dictlist.items(): 
		if val == key:
			return number
	return "No devices available."

def get_match_key(dict, key, device, field): 
	for item in dict:  
		if (item[key] == device):
			return item[field]
	return "device not available."

def read_location(location):
	try:
		reg = urlreq.urlopen(location)
		dev_data = reg.read().decode()
		dev_dict = ast.literal_eval(dev_data) 
# Creates a readable dictionary out of the Wiscelink location
		type('dict')
		return dev_dict
	except ValueError: 
		print("Invalid Selection.")

def get_svc_regs():
	svc_param_list = []
	with open("svc_reg_config") as json_data_file:
		svc_reg_data = json.load(json_data_file)

	for svc_regs, reg_name in svc_reg_data.items():
		for svc_reg, q_val in reg_name.items():
			svc_param_list.append(svc_reg)
	return svc_reg_data, svc_param_list

def reg_format(reg_format, Q):
	fixed_pn = float(reg_format)*(2**Q)
	before_dec, after_dec = str(fixed_pn).split('.') 
	before_dec = int(before_dec)
	return before_dec 

sd_hostlist = sd.query_hostapis()
sd_devlist = sd.query_devices()

host_API = get_match_key(sd_hostlist, 'name', HOSTNAME, 'devices') 
host_idx = host_API[0] 

devinfo = sd_devlist[host_idx]
if MIN_CHANNELS <= devinfo['max_input_channels']:  
	inlatency = devinfo['default_high_input_latency']

sd.default.device = [host_idx, None]
sd.default.channels = [MIN_CHANNELS, 0]

qresult = subprocess.check_output('tasklist /FI "imagename eq wisce.exe" /fo table /nh')
if not 'WISCE' in qresult.decode('utf-8'):	
	print("Must be running WISCE!") 		
	quit() 

def get_devs():
	sys_url = "http://127.0.0.1:9000/system0" 
	dev_dict = read_location(sys_url)			
	device_menu_options = []
	devices_with_links = []

	dev_list = get_reg_value('devices', dev_dict)
	for dev_name in dev_list:
			device_slot = get_reg_value('name', dev_name)
			device_link = get_reg_value('href', dev_name)
			if device_slot != '':
				device_menu_options.append(device_slot)
				devices_with_links.append({"dev_S": device_slot, "dev_L": device_link}) 

	return dev_dict, device_menu_options, devices_with_links

def get_numwav_idx(devs_with_links, data):
	spec_link = get_match_key(devs_with_links, 'dev_S', data, 'dev_L')
	spec_reg_dict = read_location(spec_link)
	field_link_set = get_reg_value('fields', spec_reg_dict)                              # Obtains a list of all fields relevant to the device
	reg_link_set = get_reg_value('registers', spec_reg_dict)
			# Obtains a list of all registers relevant to the device
	(device_ID, field_link), *rest = field_link_set.items()                            # Obtains the device ID link from the first field DEVID 
	final_device_loc = urlreq.urlopen(field_link).read()

	num_wav_idx_reg = get_reg_value('VIBEGEN_NUM_OF_WAVES', reg_link_set)				   # Obtains number of waveform indices in waveform table
	num_wav_idx_val = read_location(num_wav_idx_reg)
	num_wav_idx_val_resp = get_reg_value('value', num_wav_idx_val)

	print("NUM WAV IDX VAL RESP :\n", num_wav_idx_val_resp)
	print("REG LINK SET :\n", reg_link_set)
	return num_wav_idx_val_resp, reg_link_set

def get_reg_enc_data(svc_reg_data, reg_name, def_val, inc_val):
	q_reg = get_reg_value('regs', svc_reg_data)
	Q = float(get_reg_value(reg_name, q_reg))
	before_dec = reg_format(def_val, Q)
	step_size_add = reg_format(inc_val, Q)
	reg_enc_data = urlparse.urlencode({"value": before_dec}).encode()
	return before_dec, step_size_add, reg_enc_data

def play_wave_idx(reg_enc_data, reg_name, idx_sel, step, reg_return, before_dec, step_size_add):
	reg_enc_data = urlparse.urlencode({"value": before_dec + int(step)*step_size_add}).encode()
	svc_reg = get_reg_value(reg_name, reg_return)
	reg_encode = urlreq.urlopen(svc_reg, data=reg_enc_data)
	play_wav_reg = get_reg_value('VIBEGEN_Q_STORED', reg_return)
	mask_val = int(idx_sel) | 0x1000000		  														# masks base register entry with current index value
	enc_data = urlparse.urlencode({'value': hex(mask_val)}).encode()

	mydata = sd.rec(int((1.15+inlatency+0.5)*RATE), samplerate=RATE, channels=MIN_CHANNELS)
	time.sleep(inlatency)

	enc_wav_reg = get_reg_value('DSP_VIRTUAL1_MBOX_1', reg_return)				            # Obtains message box encoding register
	encode_to_reg = urlreq.urlopen(enc_wav_reg, data=enc_data)

	vmon = mydata[:,0]
	imon = mydata[:,1]
	acc = mydata[:,8]

	return vmon, imon, acc



### code above this point was written by David and connects the script to Wisce ###


