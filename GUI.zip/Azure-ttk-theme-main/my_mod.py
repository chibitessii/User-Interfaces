# Python Module example

def add(a, b):
   """This program adds two
   numbers and return the result"""

   result = a + b
   return result