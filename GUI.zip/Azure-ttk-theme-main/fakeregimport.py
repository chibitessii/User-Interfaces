import numpy as np
import math
import scipy.signal
from scipy.signal import savgol_filter

def get_reg_value(val, dictlist): 
# This function allows the device dictionary to be read and chosen from 
	for key, number in dictlist.items(): 
		if val == key:
			return number
	return "No devices available."

def get_match_key(dict, key, device, field): 
	for item in dict:  
		if (item[key] == device):
			return item[field]
	return "device not available."

def read_location(location):
	try:
		reg = urlreq.urlopen(location)
		dev_data = reg.read().decode()
		dev_dict = ast.literal_eval(dev_data) 
# Creates a readable dictionary out of the Wiscelink location
		type('dict')
		return dev_dict
	except ValueError: 
		print("Invalid Selection.")

def get_svc_regs():
	svc_param_list = []
	with open("svc_reg_config") as json_data_file:
		svc_reg_data = {'regs': {'SVC_XM_RE_SF': '22.0976125', 'SVC_XM_PBK_PH_PILOT_LO_LEVEL': '0', 'SVC_XM_INIT_PH_PILOT_HI_LEVEL': '0', 'SVC_XM_PBK_PH_PILOT_LO_PERIOD_SMP': '23.001'}}

	for svc_regs, reg_name in svc_reg_data.items():
		for svc_reg, q_val in reg_name.items():
			svc_param_list.append(svc_reg)
	return svc_reg_data, svc_param_list

def get_devs():
	device_menu_options =  ['LN2 FPGA', 'CS40L26']
	devices_with_links =  [{'dev_S': 'LN2 FPGA', 'dev_L': 'http://127.0.0.1:9000/system0/device0/'}, {'dev_S': 'CS40L26', 'dev_L': 'http://127.0.0.1:9000/system0/device1/'}]
	return device_menu_options, devices_with_links

def reg_format(reg_format, Q):
	fixed_pn = float(reg_format)*(2**Q)
	before_dec, after_dec = str(fixed_pn).split('.') 
	before_dec = int(before_dec)
	return before_dec 

def get_reg_enc_data(svc_reg_data, reg_name, def_val, inc_val):
	q_reg = get_reg_value('regs', svc_reg_data)
	Q = float(get_reg_value(reg_name, q_reg))
	before_dec = reg_format(def_val, Q)
	step_size_add = reg_format(inc_val, Q)
	return before_dec, step_size_add

def play_wave_idx(reg_name, idx_sel, step, reg_return, before_dec, step_size_add):
	sine_wave_thing = np.linspace(-np.pi, np.pi, 100)
	vmon = np.sin(sine_wave_thing*(before_dec + int(step)*step_size_add)) # y = sin(x)
	vmon = savgol_filter(vmon, 99, 6)
	imon = np.sin(2*sine_wave_thing*(before_dec + int(step/2)*step_size_add)) # y = sin(2x)
	imon = savgol_filter(imon, 99, 6)
	acc = np.sin(3*sine_wave_thing*(before_dec + int(step/3)*step_size_add)) # y = sin(3x)
	acc = savgol_filter(acc, 99, 6)
	return vmon, imon, acc

