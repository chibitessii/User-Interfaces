import pylab
import matplotlib._pylab_helpers
import matplotlib.pyplot as plt
import tkinter as tk
import sounddevice as sd
import numpy as np
import pandas as pd
import urllib.request as urlreq
import urllib.parse as urlparse
import json, time, ast, os, csv, sys, subprocess
import fakeregimport
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, 
NavigationToolbar2Tk)
from matplotlib import backend_bases
from matplotlib.figure import Figure
from tkinter import *
from tkinter import filedialog
from tkinter import ttk
from pylab import *
from ttkthemes import ThemedTk 
from matplotlib.widgets import Cursor
from tkinter import font

np.set_printoptions(threshold=sys.maxsize)
device_menu_options, devices_with_links = fakeregimport.get_devs()

class ScrollableFrame(ttk.Frame):
	def __init__(self, parent):
			super().__init__(parent)

			self.canvas = tk.Canvas(self, bd=3, highlightthickness=2, bg='grey', relief=SUNKEN)
			self.canvas.bind('<MouseWheel>', lambda event: self.canvas.yview_scroll(int(-1*(event.delta/120)), "units"))
			scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
			self.scrollable_frame = Frame(self.canvas)
			self.scrollable_frame.bind("<Configure>",lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
			self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="center")
			self.canvas.configure(yscrollcommand=scrollbar.set, width=200, height=540)

			self.canvas.pack(side = LEFT, expand = True, fill=tk.BOTH)
			scrollbar.pack(side = LEFT, expand = True, fill=tk.BOTH)
			scrollbar.pack_forget()

class Application(ttk.Frame):
	def __init__(self, master):
		ttk.Frame.__init__(self, master)
		
		root.columnconfigure(0, weight=1)
		root.rowconfigure(0, weight=1)

		frame1 = Frame(root)
		frame1.grid(row=0, column = 0, sticky = 'nsew')
		frame7 = Frame(root)
		frame7.grid(row=1, column=0, sticky = 'nsew')
		frame2 = ttk.LabelFrame(frame7, text='')
		frame2.grid(row=1, column=1, sticky = 'nsew')
		frame3 = Frame(root)
		frame3.grid(row = 2, column = 0, sticky = 'nsew')
		self.frame4 = ScrollableFrame(root)
		self.frame4.grid(row=0, column=3, sticky = N, rowspan = 3)
		frame5 = Frame(root)
		frame5.grid(row=2, column=3, sticky=W)
		frame6 = ttk.LabelFrame(frame7, text='')
		frame6.grid(row=1, column=0, sticky='nsew')

		def make_entry(self, frame, width, side):
			self = ttk.Entry(frame, width=width)
			self.pack(side=side)
			return self

		device_list = sorted(device_menu_options)
		heading = ['Param Config #','Parameter Name', 'Start Value', 'Step Size', 'Num. Steps']
		play_btn_pic= PhotoImage(file='resized_play.png')
		self.svc_reg_data, svc_param_list = fakeregimport.get_svc_regs()
		self.data_list = []
		self.data_dict = {}
		self.param_num = 0

		ttk.Label(frame6, width=20, text="Registers", anchor = 'center', font="Helvetica 12 bold").pack(side=TOP, expand=True, fill=tk.BOTH)
		self.svc_listbox = Listbox(frame6, highlightthickness=2, relief=tk.SUNKEN, font='Courier 11', width=40)
		self.svc_listbox.pack(fill=tk.BOTH, expand = True, side = LEFT)
		[self.svc_listbox.insert(END, svc_param) for svc_param in svc_param_list]

		self.device_listbox = ttk.Treeview(frame1, columns=0, show='headings')
		self.device_listbox.column(0, width=200, anchor='center', stretch=True)
		self.device_listbox.pack(side=LEFT, padx=60)
		self.device_listbox.heading(0, text='Device')

		self.index_listbox = ttk.Treeview(frame1, columns=1, show='headings')
		self.index_listbox.column(1, width=100, anchor='center', stretch=True)
		self.index_listbox.pack(side=LEFT, padx=15)
		self.index_listbox.heading(1, text='Waveform Index')

		ttk.Label(frame2, width=20, text="Parameters\n", anchor = 'n', font="Helvetica 12 bold").pack(side=TOP, expand=True, fill=tk.BOTH)
		ttk.Label(frame2, width=12, text="Start Value", anchor = 'center', font="Helvetica 10 bold").pack(side=TOP, expand=True, fill=tk.BOTH)
		self.start_entry = make_entry(self, frame2, 12, TOP)
		ttk.Label(frame2, width=12, text="Step_Size", anchor = 'center',font="Helvetica 10 bold").pack(side=TOP, expand=True, fill=tk.BOTH)
		self.val_entry = make_entry(self, frame2, 12, TOP)
		ttk.Label(frame2, width=12, text="Num.Steps", anchor = 'center',font="Helvetica 10 bold").pack(side=TOP, expand=True, fill=tk.BOTH)
		self.num_entry = make_entry(self, frame2, 12, TOP)
		#ttk.Label(self.frame4, width=20, text="Figures\n", anchor = 'w', font="Helvetica 12 bold").pack(side=TOP, expand=True, fill=tk.BOTH, anchor='center')

		self.submit_button = ttk.Button(frame2, text="Insert", command=self.param_entry_button, style="AccentButton",width=10)
		self.submit_button.pack(side=TOP, fill=None,  pady=20, expand = False)

		self.play_button = ttk.Button(frame5, image=play_btn_pic, command=self.button_sel_play, width=15)
		self.play_button.image = play_btn_pic
		self.play_button.pack(side=TOP, fill=None, pady=10, expand = False)

		self.sav_fig_button = ttk.Button(frame5, text="Replot Saved Config", command=self.select_saved_datfile, style="AccentButton", width=20)
		self.sav_fig_button.pack(side=TOP, fill=None, pady=15, padx=40, expand = False) # Not yet addressed

		self.param_listbox = ttk.Treeview(frame3, columns=heading, show='headings')
		[self.param_listbox.heading(x, text=x) for x in heading]
		[self.param_listbox.column(x, width =120, anchor='center') for x in heading]
		self.param_listbox.pack(side=BOTTOM, expand=True, fill = tk.BOTH)

		self.save_delete_menu = Menu(frame3, tearoff=0)
		self.save_delete_menu.add_command(label="Delete Config", command=self.delete_config)
		self.save_delete_menu.add_command(label="Save Config Data", command=self.save_config_csv)

		self.updated_p_listbox = self.param_listbox 

		for dev_count, dev in enumerate(device_list):
			self.device_listbox.insert('', 'end', dev, text=device_list[dev_count], value=dev)

		self.device_listbox.bind('<<TreeviewSelect>>', lambda dev_sel_event: self.dev_sel_play(dev_sel_event))
		self.index_listbox.bind('<<TreeviewSelect>>', lambda idx_sel_event: self.idx_sel_play(idx_sel_event))
		self.updated_p_listbox.bind('<<TreeviewSelect>>', lambda parc_sel_event: self.param_sel_play(parc_sel_event))
		self.svc_listbox.bind('<<ListboxSelect>>', lambda reg_sel_event: self.svc_sel_play(reg_sel_event))
		self.updated_p_listbox.bind("<Button-3>", lambda rc_sd_event: self.savdel_popup(rc_sd_event))

		for each in self.children:
			self.children[each].pack()
		self.location_entry = Entry(self)

	def select_param_conf(self, value, carried_val):  
		self.curItem = self.updated_p_listbox.focus()
		self.sel_list = self.updated_p_listbox.item(self.curItem, value)
		self.reg_name = self.sel_list[1]
		self.def_val = self.sel_list[2]
		self.inc_val = self.sel_list[3]
		self.step_size = self.sel_list[4]

	def savdel_popup(self, rc_sd_event):
		try:
			self.save_delete_menu.tk_popup(rc_sd_event.x_root, rc_sd_event.y_root)
		finally:
			self.save_delete_menu.grab_release()

	def delete_config(self):
		self.updated_p_listbox.delete(self.parc_sel)

	def save_config_csv(self): 
		self.tot_field_dict = {}
		fig_save_title = ""     
		self.param_sel_vals = self.select_param_conf('values', self.parc_sel)
		self.sel_tup_list = self.sel_list

		for fig_save_val in self.sel_tup_list:
			fig_save_title += str(fig_save_val) # Needs more clear formatting

		for plot_num in self.data_dict.values():
			for field_name in plot_num: 
				self.field_name_vals = field_name.values()
				self.field_name_list = field_name.keys()
				self.field_dict = dict(zip(self.field_name_list, self.field_name_vals))
			field_name_df = pd.DataFrame(plot_num)
			field_name_df.to_csv(str(fig_save_title)+".csv")

	def select_saved_datfile(self):
		my_filetypes = [('all files', '.*'), ('Comma Separated Value', '.csv')]
		self.location = filedialog.askopenfilename(parent=root, initialdir=os.getcwd(), title="Please select a folder:")

		if str(self.location_entry.get()) == '': 
			with open(self.location, newline='') as self.csvfile:
				self.replot_saved_data()
		else:
			with open(str(self.location_entry.get()), newline='') as self.csvfile:
				self.replot_saved_data()

	def replot_saved_data(self):
		read_fig_file = pd.read_csv(self.csvfile)
		read_fig_file.plot(0, ["voltage"], subplots=True) # Doesn't work

	def child_destroy(self):
		for child in self.frame4.scrollable_frame.winfo_children():
			child.destroy()

	def param_list_append(self, param_list, voltage, current, acceleration):
		param_list.append({ "plot_num": self.plot_num,
							"cur_wav_idx": self.idx_sel,
							"data_num": self.data_count, "voltage": voltage, 
														 "current": current,
														 "acceleration": acceleration,
														 "fig_title": self.fig_label})
	
	def dev_sel_play(self, dev_sel_event): 
		self.dev_sel = dev_sel_event.widget.selection()[0]

		if self.dev_sel != None and dev_sel_event.widget.selection() != (): 
			data = dev_sel_event.widget.item(self.dev_sel)
			data = data['text']
			num_wav_idx = 3

			for idx in range(num_wav_idx):
				self.index_listbox.insert('', 'end', idx, value = idx) 	
			self.register_return = 'Current Reg'
	
	def idx_sel_play(self, idx_sel_event): 
		self.idx_sel = idx_sel_event.widget.selection()[0]
	
	def svc_sel_play(self, reg_sel_event):
		self.reg_sel = reg_sel_event.widget.curselection()[0]

	def param_sel_play(self, parc_sel_event): 
		self.parc_sel = parc_sel_event.widget.selection()[0]

	def param_entry_button(self):
		self.updated_p_listbox.insert('', 'end', 
									values=(
											"Config_"+str(self.param_num),
											self.svc_listbox.get(self.reg_sel),
											self.start_entry.get(),
											self.val_entry.get(),
											self.num_entry.get()))
		self.param_num = self.param_num + 1
	
	def button_sel_play(self): 
		self.temp_param_list = []

		if self.parc_sel in self.data_dict: 
			self.child_destroy()
			for item in self.data_dict[self.parc_sel]:
				self.cur_wav_idx = item['cur_wav_idx']
				self.cur_data_num = item['data_num']
				self.cur_voltage = item['voltage']
				self.cur_current = item['current']
				self.cur_acceleration = item['acceleration']

				self.plot_realtime_creator(self.cur_wav_idx, 
										   str(int((self.parc_sel).strip("I00"))-1), 
										   str(self.cur_data_num - 1), 
										   self.cur_voltage, 
										   self.cur_current, 
										   self.cur_acceleration)
				self.plot_num = plt.gcf().number

				self.param_list_append(self.data_list, 
									   self.cur_voltage, 
									   self.cur_current, 
									   self.cur_acceleration) # might not work- might append wav idx and data num from another graph because of self
				self.connect_artists()

		else:
			self.param_sel_vals = self.select_param_conf('values', self.parc_sel)
			step_size, step_size_add = fakeregimport.get_reg_enc_data(self.svc_reg_data, 
																	  self.reg_name, 
																	  self.def_val, 
																	  self.inc_val)
			self.child_destroy()
			self.data_count = 0

			for self.step in range(int(self.step_size)):
				self.vmon, self.imon, self.acc = fakeregimport.play_wave_idx(self.reg_name, 
																			 self.idx_sel, 
																			 self.step, 
																			 self.register_return, 
																			 step_size, 
																			 step_size_add) 
																			 					
				self.plot_realtime(self.vmon,
								   self.imon,
								   self.acc)
								   
		self.data_dict[self.parc_sel] = self.temp_param_list

	def plot_realtime_creator(self, idx, par, step, volt, current, accel):
		self.fig = plt.figure(figsize=(3.3, 2), dpi=60, constrained_layout=True, frameon=True)
		self.fig.suptitle('Idx_{}'.format(idx)+"_Config_"+par+"_Step_"+step, font='Times New Roman', fontsize=13, color= '#696969', fontweight='bold')	
		self.emb_canvas = FigureCanvasTkAgg(self.fig, master=self.frame4.scrollable_frame)   
		self.emb_canvas.get_tk_widget().pack(padx=2, pady=2)
		self.emb_plot = self.fig.add_subplot(111)

		sd.wait()
		self.multi_plotter(self.emb_plot, volt, current, accel)        
		self.fig_label = self.fig._suptitle.get_text()
		self.fig.legend(('volt', 'current', 'accel'), loc="upper left")

	def plot_realtime(self, voltage, current, acceleration):
		self.data_count = self.data_count + 1
		self.plot_realtime_creator(self.idx_sel, 
								   str(self.param_num - 1), 
								   str(self.step), 
								   voltage, 
								   current, 
								   acceleration)
		self.plot_num = plt.gcf().number
		self.param_list_append(self.data_list, voltage, current, acceleration)
		self.param_list_append(self.temp_param_list, voltage, current, acceleration)
		self.connect_artists()

	def connect_artists(self):
		self.es_connect = self.emb_canvas.callbacks.connect('button_press_event', self.pic_enlarge_set)
		self.ef_connect = self.fig.canvas.mpl_connect('figure_enter_event', self.enter_figure)
		self.lf_connect = self.fig.canvas.mpl_connect('figure_leave_event', self.leave_figure)
		self.active_fig = matplotlib._pylab_helpers.Gcf.get_active()

	def show_figure(self, fig):
		dummy_fig = plt.figure()
		new_manager = dummy_fig.canvas.manager
		new_manager.canvas.figure = fig
		fig.set_canvas(new_manager.canvas)

	def pic_enlarge_set(self, enlarge_sel_event):
		self.new_data_num = enlarge_sel_event.canvas.figure.number
		voltage = fakeregimport.get_match_key(self.data_list, 'plot_num', self.new_data_num, 'voltage')
		current = fakeregimport.get_match_key(self.data_list, 'plot_num', self.new_data_num, 'current')
		acceleration = fakeregimport.get_match_key(self.data_list, 'plot_num', self.new_data_num, 'acceleration')
		fig_title = fakeregimport.get_match_key(self.data_list, 'plot_num', self.new_data_num, 'fig_title')

		self.active_fig = plt.Figure()
		self.active_fig.suptitle(fig_title)

		win = ThemedTk(theme="breeze")
		win.wm_title("Window")
		pop_canvas = FigureCanvasTkAgg(self.active_fig, master=win)   
		pop_canvas.get_tk_widget().pack(side=BOTTOM, expand=True, fill=tk.BOTH)

		toolbar = NavigationToolbar2Tk(pop_canvas, win, pack_toolbar = False) #creates the fancy toolbar
		toolbar.update()
		toolbar.pack(side=tk.TOP, fill=tk.BOTH)

		self.active_plot = self.active_fig.add_subplot(111)
		self.multi_plotter(self.active_plot, voltage, current, acceleration)   
		self.fig.legend(('voltage', 'current', 'acceleration'), loc="upper left")
		self.show_figure(self.active_fig)

	def multi_plotter(self, temp_canvas, volt, current, accel):
		temp_canvas.plot(volt, "-b", linewidth=1)
		temp_canvas.plot(current, "-r", linewidth=1)
		temp_canvas.plot(accel, "-g", linewidth=2)

	def enter_figure(self, event):
		event.canvas.figure.patch.set_facecolor('#4db8ff')
		event.canvas.draw()

	def leave_figure(self, event):
		event.canvas.figure.patch.set_facecolor('white')
		event.canvas.draw()

#root = ThemedTk(theme="breeze")
#root.attributes('-topmost', 'true')
root=tk.Tk()
root.option_add("*tearOff", False) # This is always a good idea
root.tk.call('source', 'azure-dark.tcl')
ttk.Style().theme_use('azure-dark')
app = Application(root)
root.mainloop()